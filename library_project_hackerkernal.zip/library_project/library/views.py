from django.views.generic import CreateView
from django.urls import reverse_lazy
from .models import Author, Book, BorrowRecord
from .forms import AuthorForm, BookForm, BorrowRecordForm

class AuthorCreateView(CreateView):
    model = Author
    form_class = AuthorForm
    template_name = 'library/form.html'
    success_url = reverse_lazy('author-list')

class BookCreateView(CreateView):
    model = Book
    form_class = BookForm
    template_name = 'library/form.html'
    success_url = reverse_lazy('book-list')

class BorrowCreateView(CreateView):
    model = BorrowRecord
    form_class = BorrowRecordForm
    template_name = 'library/form.html'
    success_url = reverse_lazy('borrow-list')
