from django.urls import path
from .views import (
    AuthorCreateView, BookCreateView, BorrowCreateView,
    AuthorListView, BookListView, BorrowListView, ExportExcelView
)

urlpatterns = [
    path('authors/', AuthorListView.as_view(), name='author-list'),
    path('books/', BookListView.as_view(), name='book-list'),
    path('borrows/', BorrowListView.as_view(), name='borrow-list'),
    path('export/', ExportExcelView.as_view(), name='export-excel'),

    # ✅ Form pages
    path('authors/add/', AuthorCreateView.as_view(), name='author-add'),
    path('books/add/', BookCreateView.as_view(), name='book-add'),
    path('borrows/add/', BorrowCreateView.as_view(), name='borrow-add'),
]
