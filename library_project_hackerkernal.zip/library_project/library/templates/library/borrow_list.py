<!DOCTYPE html>
<html>
<head>
  <title>Borrow Records</title>
</head>
<body>
  <h1>Borrow Records</h1>

  <ul>
    {% for record in records %}
      <li>{{ record.user_name }} borrowed {{ record.book }} on {{ record.borrow_date }} (return: {{ record.return_date }})</li>
    {% empty %}
      <li>No borrow records found.</li>
    {% endfor %}
  </ul>

  {% if is_paginated %}
    <div>
      {% if page_obj.has_previous %}
        <a href="?page=1">First</a>
        <a href="?page={{ page_obj.previous_page_number }}">Previous</a>
      {% endif %}
      <span>Page {{ page_obj.number }} of {{ page_obj.paginator.num_pages }}</span>
      {% if page_obj.has_next %}
        <a href="?page={{ page_obj.next_page_number }}">Next</a>
        <a href="?page={{ page_obj.paginator.num_pages }}">Last</a>
      {% endif %}
    </div>
  {% endif %}
</body>
</html>
